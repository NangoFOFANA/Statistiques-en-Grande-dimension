#########CODE SOURCEProjet 2 stat##########
### Exercice 1 ####
## Q1-a
n=100
x=1:n/n

## Q1-b
sigma=0.2
f=function(x){
  s=(x^2*2^(x-1)-(x-0.5)^(3))*sin(10*x)
  return(s)
}
Y=f(x)+sigma*rnorm(n)
### Q2
plot(x,Y, col='red',main = 'Nuage de point & f')
lines(x,f(x),col='blue',lwd=2)
legend("topleft", legend=c("x,y", "f"),col=c("red", "blue"), lty=2:1, cex=0.8)


### Q 3-a
phi=function(x,d){
  if(d==1){c=rep(1,length(x))}
  else if(d%%2==0)
    c=sqrt(2)*cos(pi*d*x)
  else
    c=sqrt(2)*sin(pi*(d-1)*x)
  return(c)
}

plot(x,phi(x,2),ylab='phi(1,2,3,4,5)' ,col='orange',type = 'l',lwd=2,main = 'les 5 premi�re fonctions')
points(x,phi(x,1),col='cyan',type = 'l',lwd=2)
points(x,phi(x,3),col='purple',type = 'l',lwd=2)
points(x,phi(x,4),col='pink',type = 'l',lwd=2)
points(x,phi(x,5),col='green',type = 'l',lwd=2)
legend("bottomleft", legend=c("Phi2","Ph1","Phi3","phi4","phi5"),
       col=c("orange","cyan","purple", "pink", "green"), lty=1:1, cex=0.8)

###Q3-b fchapD

##Construiction Yphi
Yphi=function(x,d){
  n=length(x)
  y=matrix(0,d,1)
  for (j in 1:d){
    for (i in 1:n) {
      y[j,]=y[j,]+Y[i]*phi(x[i],j)
      
    }
  }
  return(y/n)
}
# matrice G
G=function(x,d){
  n=length(x)
  w=matrix(0,d,d)
  for (j in 1:d) {
    for (k in 1:d) {
      for (i in 1:n) {
        w[j,k]=w[j,k]+phi(x[i],j)*phi(x[i],k)
      }
    }
  }
  return(w/n)
}

## achap

achap=function(x,d){
  return(solve(G(x,d),Yphi(x,d)))
}

## enfin fchapD
fchap_D=function(x,d){
  n=length(x)
  t=0
  c=achap(x,d)
  for (j in 1:d) {
    t=t+c[j,]*phi(x,j)
  }
  return(t/n)
}
## Representation de tous les estimateurs en fonction de D
plot(x,fchap_D(x,1), type = 'l',col='red',lwd=1,main = 'estimateur D=1')  #pour D=1
plot(x,fchap_D(x,5), type = 'l',col='blue',lwd=1,main = 'estimateur D=5')  #pour D=5
plot(x,fchap_D(x,10), type = 'l',col='green',lwd=1,main = 'estimateur D=10')  #pour D=10
plot(x,fchap_D(x,15), type = 'l',col='yellow',lwd=1,main = 'estimateur D=15')  #pour D=15
plot(x,fchap_D(x,20), type = 'l',col='black',lwd=1,main = 'estimateur D=20')  #pour D=20
plot(x,fchap_D(x,30), type = 'l',col='orange',lwd=1, main = 'estimateur D=30')  #pour D=30
plot(x,fchap_D(x,50), type = 'l',col='red',lwd=1,main = 'estimateur D=50')  #pour D=50


### Q 3-c Risque empirique


r1 = (f(x)-fchap_D(x,1))^2
r2 = (f(x)-fchap_D(x,5)^2)
r3 = (f(x)-fchap_D(x,10))^2
r4 = (f(x)-fchap_D(x,15))^2
r5 = (f(x)-fchap_D(x,20))^2
r6 = (f(x)-fchap_D(x,30))^2
r7 = (f(x)-fchap_D(x,50))^2

R1 = mean(r1)
R2 = mean(r2)
R3 = mean(r3)
R4 = mean(r4)
R5 = mean(r5)
R6 = mean(r6)
R7 = mean(r7)

risk = c(R1,R2,R3,R4,R5,R6,R7)
D = c(1,5,10,15,20,30,50)
plot(D,risk, type = "o",main = 'Representation du risque empirique')



#### Q-3-d Choix de D


sigma2=var(Y-fchap_D(x,5)) ##sigma^2

cv1=-t(achap(x,1))%*%G(x,1)%*%achap(x,1)+2*sigma2*1/n # D=1
cv2=-t(achap(x,5))%*%G(x,5)%*%achap(x,5)+2*sigma2*5/n # D=5
cv3=-t(achap(x,10))%*%G(x,10)%*%achap(x,10)+2*sigma2*10/n # D=10
cv4=-t(achap(x,15))%*%G(x,15)%*%achap(x,15)+2*sigma2*15/n # D=15
cv5=-t(achap(x,20))%*%G(x,20)%*%achap(x,20)+2*sigma2*20/n # D=20
cv6=-t(achap(x,30))%*%G(x,30)%*%achap(x,30)+2*sigma2*30/n # D=30
cv7=-t(achap(x,50))%*%G(x,50)%*%achap(x,50)+2*sigma2*50/n # D=50
##minimisation 
K=c(cv1,cv2,cv3,cv4,cv5,cv6,cv7)
print(K)
KP=which.min(K)

#3-e # ici D=5
# ici c'est D=5 qui minimise
plot(x,fchap_D(x,5), type = 'l',col='red',lwd=1,main = 'Estimateur')  #pour D=5



#Q4






########### EXERCICE 2

setwd("C:/Users/33758/Downloads") ## fonction permettant de localiser le jeux de donn�e
getwd()
population=read.csv(file = "population-par-age-et-par-sexe-2006-a-2016-donnees-insee.csv", header = TRUE, sep=";")
attach(population) 
names(population)
str(population)
B=nombre

A = (B-min(B))/(max(B)-min(B)) #Normalisation 
Z=sort(A)
m=length(Z) # taille de Z
sigma=0.2 # Ecart type
h=function(Z){
  l=(Z^2*2^(Z-1)-(Z-0.5)^(3))*sin(10*Z)
  return(l)
}
Y1=h(Z)+sigma*rnorm(m) #fonction de regression de la nouvelle valeurs 
plot(Z,Y1,col='purple',main = 'Nuage de point de (Z,Y1)')
legend("topleft", legend=c("Z,Y1"),col=c("purple"), lty=1:2, cex=0.8)
###################


#### Construction de l'estimateurhchapD


## construction de phiz
phiz=function(Z,d){
  if(d==1){c=rep(1,length(Z))}
  else if(d%%2==0)
    c=sqrt(2)*cos(pi*d*Z)
  else
    c=sqrt(2)*sin(pi*(d-1)*Z)
  return(c)
}

## construction de Y1phi
Y1phi=function(Z,d){
  n=length(Z)
  y=matrix(0,d,1)
  for (j in 1:d){
    for (i in 1:n) {
      y[j,]=y[j,]+Y1[i]*phiz(Z[i],j)
      
    }
  }
  return(y/n)
}
#matrice G
Gz=function(Z,d){
  n=length(Z)
  w=matrix(0,d,d)
  for (j in 1:d) {
    for (k in 1:d) {
      for (i in 1:n) {
        w[j,k]=w[j,k]+phiz(Z[i],j)*phiz(Z[i],k)
      }
    }
  }
  return(w/n)
}

## construction de achapz
achapz=function(Z,d){
  return(solve(Gz(Z,d),Y1phi(Z,d)))
}

## construction maintenant de hchapD
hchap_D=function(Z,d){
  n=length(Z)
  t=0
  c=achapz(Z,d)
  for (j in 1:d) {
    t=t+c[j,]*phiz(Z,j)
  }
  return(t/n)
}
## Construction de l'estimateur hchapD pour D={1,5,10,15,20,30,50}
plot(Z,hchap_D(Z,1), type = 'l',col='red',lwd=1)  #pour D=1
plot(Z,hchap_D(Z,5), type = 'l',col='blue',lwd=1)  #pour D=5
plot(Z,hchap_D(Z,10), type = 'l',col='green',lwd=1)  #pour D=10
plot(Z,hchap_D(Z,15), type = 'l',col='yellow',lwd=1)  #pour D=15
plot(Z,hchap_D(Z,20), type = 'l',col='black',lwd=1)  #pour D=20
plot(Z,hchap_D(Z,30), type = 'l',col='orange',lwd=1)  #pour D=30
plot(Z,hchap_D(Z,50), type = 'l',col='red',lwd=1)  #pour D=50


## Choix de D

sigma2=var(Y1-hchap_D(Z,5)) ##sigma^2

cz1=-t(achapz(Z,1))%*%Gz(Z,1)%*%achapz(Z,1)+2*sigma2*1/n # D=1
cz2=-t(achapz(Z,5))%*%Gz(Z,5)%*%achapz(Z,5)+2*sigma2*5/n # D=5
cz3=-t(achapz(Z,10))%*%Gz(Z,10)%*%achapz(Z,10)+2*sigma2*10/n # D=10
cz4=-t(achapz(Z,15))%*%Gz(Z,15)%*%achapz(Z,15)+2*sigma2*15/n # D=15
cz5=-t(achapz(Z,20))%*%Gz(Z,20)%*%achapz(Z,20)+2*sigma2*20/n # D=20
cz6=-t(achapz(Z,30))%*%Gz(Z,30)%*%achapz(Z,30)+2*sigma2*30/n # D=30
cz7=-t(achapz(Z,50))%*%Gz(Z,50)%*%achapz(Z,50)+2*sigma2*50/n # D=50

H=c(cz1,cz2,cz3,cz4,cz5,cz6,cz7)

### MINIMISATION
CP=which.min(H)


## tra�ons l'estimateur correspondant ici D=10 qui minimmise 

plot(Z,hchap_D(Z,10), type = 'l',col='green',lwd=1,main = 'Estimateur hchap10')  #pour D=10



#Q5 Comnentons
